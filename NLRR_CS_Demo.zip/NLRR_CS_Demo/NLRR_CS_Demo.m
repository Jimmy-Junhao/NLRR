clc
clear
m_20=0; 
m_30=0;    
m_40=0;  
m_10=0;  
m_50=0; 
m_60=0; 

All_data_Results_2_20 = cell(1,200);
All_data_Results_2_30 = cell(1,200);
All_data_Results_2_40 = cell(1,200);
All_data_Results_2_10 = cell(1,200);
All_data_Results_2_50 = cell(1,200);
All_data_Results_2_60 = cell(1,200);

for i = 1:11
ImageNum =i;

switch ImageNum
    
            case 1
                filename = 'Fence_256';
            case 2
                filename = 'foreman256';
            case 3
                filename = 'girl256';
            case 4
                filename = 'House256';    
            case 5
                filename = 'Leaves256';                 
            case 6
                filename = 'lin_256';
            case 7
                filename = 'Monarch256';
            case 8
                filename = 'Parrots256';
            case 9
                filename = 'plants_256';    
            case 10
                filename = 'starfish256'; 
                
            case 11
                filename = 'Barbara256';

end
for j  =   1:5
    

filename

ratio_Num        =       [0.1, 0.2, 0.3, 0.4, 0.5]; 
 

ratio             =       ratio_Num(j)

sigma             =       sqrt(2);
 

 if  ratio   == 0.1
     
          mu = 0.5; c  = 0.04; err  = 8E-05;
     
 elseif ratio   == 0.2
     
          mu = 0.5; c  = 0.01; err  = 4.9E-05;
                             
 elseif ratio   == 0.3
     
          mu = 0.5; c  = 0.009; err  = 3.2E-05;
          
  elseif ratio   == 0.4
     
          mu = 0.5; c  = 0.007; err  = 1.75E-05;
          
 else
     
          mu = 0.5; c  = 0.006; err  = 1.35E-05; 
 end


 if  j == 1 
     

     
 [Ori, ratio,  PSNR_Final,FSIM_Final,SSIM_Final,Time_s, dif]= NLRR_CS_Test(filename,  ratio, sigma, mu, c, err);
 
 m_10= m_10+1;
 
 s=strcat('A',num2str(m_10));
 
 All_data_Results_2_10{m_10}={Ori, ratio, PSNR_Final,FSIM_Final,SSIM_Final,Time_s};
 
 xlswrite('NLRR_CS_ratio_0.1.xls', All_data_Results_2_10{m_10},'sheet1',s);
 
 
 
 
 
 elseif  j == 2
     
 
[Ori, ratio,  PSNR_Final,FSIM_Final,SSIM_Final,Time_s, dif]= NLRR_CS_Test(filename,  ratio, sigma, mu, c, err);
 
 m_20= m_20+1;
 
 s=strcat('A',num2str(m_20));
 
 All_data_Results_2_20{m_20}={Ori, ratio, PSNR_Final,FSIM_Final,SSIM_Final,Time_s};
 
 xlswrite('NLRR_CS_ratio_0.2.xls', All_data_Results_2_20{m_20},'sheet1',s);
 
 
 
  elseif  j == 3
      
 
     
 [Ori, ratio,  PSNR_Final,FSIM_Final,SSIM_Final,Time_s, dif]= NLRR_CS_Test(filename,  ratio, sigma, mu, c, err);
 
 
 m_30= m_30+1;
 
 s=strcat('A',num2str(m_30));
 
 All_data_Results_2_30{m_30}={Ori, ratio, PSNR_Final,FSIM_Final,SSIM_Final,Time_s};
 
xlswrite('NLRR_CS_ratio_0.3.xls', All_data_Results_2_30{m_30},'sheet1',s);

 
 
  elseif  j == 4
    
 [Ori, ratio,  PSNR_Final,FSIM_Final,SSIM_Final,Time_s, dif]= NLRR_CS_Test(filename,  ratio, sigma, mu, c, err);
 
 
 m_40= m_40+1;
 
 s=strcat('A',num2str(m_40));
 
 All_data_Results_2_40{m_40}={Ori, ratio, PSNR_Final,FSIM_Final,SSIM_Final,Time_s};
 
 xlswrite('NLRR_CS_ratio_0.4.xls', All_data_Results_2_40{m_40},'sheet1',s);
 
 
 
 else

 [Ori, ratio,  PSNR_Final,FSIM_Final,SSIM_Final,Time_s, dif]= NLRR_CS_Test(filename,  ratio, sigma, mu, c, err);
 
 
 m_50= m_50+1;
 
 s=strcat('A',num2str(m_50));
 
 All_data_Results_2_50{m_50}={Ori, ratio, PSNR_Final,FSIM_Final,SSIM_Final,Time_s};
 
 xlswrite('NLRR_CS_ratio_0.5.xls', All_data_Results_2_50{m_50},'sheet1',s);
 
 
 end

clearvars -except filename i m_20 All_data_Results_2_20 m_30 All_data_Results_2_30 m_40 All_data_Results_2_40 m_10 All_data_Results_2_10 m_50 All_data_Results_2_50 m_60 All_data_Results_2_60
end
clearvars -except filename m_20 All_data_Results_2_20 m_30 All_data_Results_2_30 m_40 All_data_Results_2_40 m_10 All_data_Results_2_10 m_50 All_data_Results_2_50 m_60 All_data_Results_2_60
end






         